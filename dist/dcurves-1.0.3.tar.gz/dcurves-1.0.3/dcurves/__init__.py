from dcurves import load_test_data
from dcurves.dca import dca
from dcurves.plot_graphs import plot_graphs



























